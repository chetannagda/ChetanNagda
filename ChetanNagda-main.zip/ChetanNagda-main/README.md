# Chetan Nagda
MyPage

A simple website/page made with pure HTML5 & CSS to share all 
your social accounts from a single page.
You can customize as per your choices.

Here the preview-
https://github.com/chetannagda/ChetanNagda
